"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockAdjustmentsService = void 0;
var common_1 = require("@nestjs/common");
// Adjustments above this many base units require manager/admin approval
// before the resulting inventory transaction is posted (see AUDIT rule:
// "High-value adjustments require manager approval").
var APPROVAL_THRESHOLD = 10;
var StockAdjustmentsService = function () {
    var _classDecorators = [(0, common_1.Injectable)()];
    var _classDescriptor;
    var _classExtraInitializers = [];
    var _classThis;
    var StockAdjustmentsService = _classThis = /** @class */ (function () {
        function StockAdjustmentsService_1(prisma, inventoryService, auditService) {
            this.prisma = prisma;
            this.inventoryService = inventoryService;
            this.auditService = auditService;
        }
        StockAdjustmentsService_1.prototype.findAll = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.prisma.stockAdjustment.findMany({
                            orderBy: { createdAt: 'desc' },
                            include: { product: true, createdBy: { select: { id: true, name: true } }, approvedBy: { select: { id: true, name: true } } },
                        })];
                });
            });
        };
        StockAdjustmentsService_1.prototype.create = function (dto, actorId, actorRole) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.prisma.$transaction(function (tx) { return __awaiter(_this, void 0, void 0, function () {
                            var unit, currentStockBase, physicalBase, differenceBase, requiresApproval, isManagerOrAbove, approvedById, adjustment;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, tx.productUnit.findUniqueOrThrow({ where: { id: dto.unitId } })];
                                    case 1:
                                        unit = _a.sent();
                                        return [4 /*yield*/, this.inventoryService.getCurrentStock(dto.productId, tx)];
                                    case 2:
                                        currentStockBase = _a.sent();
                                        physicalBase = dto.physicalQuantity * Number(unit.quantityInBaseUnit);
                                        differenceBase = physicalBase - currentStockBase;
                                        requiresApproval = Math.abs(differenceBase) > APPROVAL_THRESHOLD;
                                        isManagerOrAbove = actorRole === 'ADMIN' || actorRole === 'MANAGER';
                                        approvedById = requiresApproval ? (isManagerOrAbove ? actorId : null) : actorId;
                                        return [4 /*yield*/, tx.stockAdjustment.create({
                                                data: {
                                                    productId: dto.productId,
                                                    systemQuantity: currentStockBase,
                                                    physicalQuantity: physicalBase,
                                                    difference: differenceBase,
                                                    reason: dto.reason,
                                                    notes: dto.notes,
                                                    createdById: actorId,
                                                    approvedById: approvedById !== null && approvedById !== void 0 ? approvedById : undefined,
                                                },
                                            })];
                                    case 3:
                                        adjustment = _a.sent();
                                        if (!approvedById) return [3 /*break*/, 5];
                                        return [4 /*yield*/, this.inventoryService.recordMovement({
                                                productId: dto.productId,
                                                unitId: dto.unitId,
                                                transactionType: 'ADJUSTMENT',
                                                quantityInUnit: differenceBase / Number(unit.quantityInBaseUnit),
                                                referenceType: 'STOCK_ADJUSTMENT',
                                                referenceId: adjustment.id,
                                                createdById: actorId,
                                            }, tx)];
                                    case 4:
                                        _a.sent();
                                        _a.label = 5;
                                    case 5: return [4 /*yield*/, this.auditService.log({
                                            userId: actorId,
                                            action: 'STOCK_ADJUSTMENT',
                                            entityType: 'StockAdjustment',
                                            entityId: adjustment.id,
                                            newValues: { differenceBase: differenceBase, reason: dto.reason, pendingApproval: !approvedById },
                                        })];
                                    case 6:
                                        _a.sent();
                                        return [2 /*return*/, __assign(__assign({}, adjustment), { pendingApproval: !approvedById })];
                                }
                            });
                        }); })];
                });
            });
        };
        StockAdjustmentsService_1.prototype.approve = function (id, actorId) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, this.prisma.$transaction(function (tx) { return __awaiter(_this, void 0, void 0, function () {
                            var adjustment, _a, _b;
                            var _c;
                            return __generator(this, function (_d) {
                                switch (_d.label) {
                                    case 0: return [4 /*yield*/, tx.stockAdjustment.update({
                                            where: { id: id },
                                            data: { approvedById: actorId },
                                        })];
                                    case 1:
                                        adjustment = _d.sent();
                                        _b = (_a = this.inventoryService).recordMovement;
                                        _c = {
                                            productId: adjustment.productId
                                        };
                                        return [4 /*yield*/, tx.product.findUnique({ where: { id: adjustment.productId }, include: { units: { where: { isBaseUnit: true } } } })];
                                    case 2: return [4 /*yield*/, _b.apply(_a, [(_c.unitId = (_d.sent())
                                                .units[0].id,
                                                _c.transactionType = 'ADJUSTMENT',
                                                _c.quantityInUnit = Number(adjustment.difference),
                                                _c.referenceType = 'STOCK_ADJUSTMENT',
                                                _c.referenceId = adjustment.id,
                                                _c.createdById = actorId,
                                                _c), tx])];
                                    case 3:
                                        _d.sent();
                                        return [4 /*yield*/, this.auditService.log({
                                                userId: actorId,
                                                action: 'APPROVE_STOCK_ADJUSTMENT',
                                                entityType: 'StockAdjustment',
                                                entityId: id,
                                            })];
                                    case 4:
                                        _d.sent();
                                        return [2 /*return*/, adjustment];
                                }
                            });
                        }); })];
                });
            });
        };
        return StockAdjustmentsService_1;
    }());
    __setFunctionName(_classThis, "StockAdjustmentsService");
    (function () {
        var _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        StockAdjustmentsService = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return StockAdjustmentsService = _classThis;
}();
exports.StockAdjustmentsService = StockAdjustmentsService;
